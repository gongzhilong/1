# list-1, implement fixed-size array list, following the project structure in this repository.
You only need to add code to list.c and test code in main.c
You only need to submit list.c file

