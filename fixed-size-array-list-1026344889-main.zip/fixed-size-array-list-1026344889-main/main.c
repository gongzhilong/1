#include <stdio.h>

#include "list.h"

void main()
{
	/* */
	struct list *l;
	l = create_list();

  /* other test code */

	free(l);
}
