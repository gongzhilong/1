#pragma once

#define MAX_ELE 1024

#define T	char

